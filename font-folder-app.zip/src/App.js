import React from "react";
import { fonts } from "./fonts";

function App() {
  return (
    <div className="container">
      <h1>Font Folder</h1>
      <div className="font-list">
        {fonts.map((font, index) => (
          <div key={index} className="font-card">
            <h2>{font.name}</h2>
            <p style={{ fontFamily: font.name }}>{font.sample}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;