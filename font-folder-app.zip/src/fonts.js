export const fonts = [
  { name: "Roboto", sample: "The quick brown fox jumps over the lazy dog." },
  { name: "Montserrat", sample: "The quick brown fox jumps over the lazy dog." },
  { name: "BUSTAMI", sample: "The quick brown fox jumps over the lazy dog." },
  { name: "Open Sans", sample: "The quick brown fox jumps over the lazy dog." },
  { name: "Lato", sample: "The quick brown fox jumps over the lazy dog." }
];