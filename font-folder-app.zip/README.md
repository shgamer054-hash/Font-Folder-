# Font Folder React App

এই অ্যাপটি একটি ফন্ট ফোল্ডার হিসেবে কাজ করে। তুমি এখানে ফন্টের নাম এবং ডেমো টেক্সট দেখতে পারবে।  

**Run locally:**
```bash
npm install
npm start
```